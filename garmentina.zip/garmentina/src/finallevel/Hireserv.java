package finallevel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import checkmethods.Usernamecheck;
import garmentina.Utility;
import tables.PaymentType;

/**
 * Servlet implementation class Hireserv
 */
@WebServlet("/hireserv")
public class Hireserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Hireserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		try (PrintWriter out = response.getWriter()) {
			String numberOfItems = request.getParameter("no_of_items");
			String mail = request.getParameter("mail");
			String contact = request.getParameter("contact");
			String d_add = request.getParameter("deliveryat");
			String pincode = request.getParameter("pincode");
			String pickupat = request.getParameter("pickupat");
			String pickuppincode = request.getParameter("pickuppincode");
			String hiredays = request.getParameter("noofhiredays");
			String pay = request.getParameter("optradio");
			PaymentType pt=PaymentType.valueOf(pay);
			int numberItems=Integer.parseInt(numberOfItems);
			String username = Utility.getCookieValue(request, "auth_user");
			String id = request.getParameter("id");
			System.out.println("now the id is"+id);
			if (numberOfItems == null || numberOfItems.isEmpty() ||d_add == null || d_add.isEmpty() || contact == null || contact.isEmpty()|| pincode == null || pincode.isEmpty()|| mail == null || mail.isEmpty()|| pickupat == null || pickupat.isEmpty()|| pickuppincode == null || pickuppincode.isEmpty()|| hiredays == null || hiredays.isEmpty()) {
				out.println(numberOfItems+"  "+d_add+"  "+mail+"  "+contact+"  "+pincode+"  "+pickupat+"  "+pickuppincode+"  "+hiredays+"  "+pay);
				out.println("all the details needed to provide this service");
			} else {
				Usernamecheck.insertHire( numberItems, d_add, pincode, contact, mail, pay, username, id, pickupat, pickuppincode, hiredays);
				//out.println("User Registered. <a href='login.html'>Login</a> with new user here");
				out.println("Your products will be hired soon");	
			}

		}
	}
}
				
