package finallevel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import checkmethods.Usernamecheck;
import garmentina.Utility;
import tables.PaymentType;


/**
 * Servlet implementation class Export
 */
@WebServlet("/exportserv")
public class Exportserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Exportserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try (PrintWriter out = response.getWriter()) {
			String numberOfItems = request.getParameter("no_of_items");
			String mail = request.getParameter("mail");
			String contact = request.getParameter("contact");
			String d_add = request.getParameter("deliveryat");
			String pincode = request.getParameter("pincode");
			String pay = request.getParameter("optradio");
			PaymentType pt=PaymentType.valueOf(pay);
			int numberItems=Integer.parseInt(numberOfItems);
			String username = Utility.getCookieValue(request, "auth_user");
			String id = request.getParameter("id");
			System.out.println("now the id is"+id);
			//Session session = HButil.get().openSession();
			//String hql = "select * from user_credential where auth_key!=''";
			//Query query = session.createQuery(hql);
			//List<String> userName = query.getResultList();
			//String uname="";
			//for(String var:userNamse){
				//uname=uname+var;
			//}
			if (numberItems == 0 ||d_add == null || d_add.isEmpty() || contact == null || contact.isEmpty()|| pincode == null || pincode.isEmpty()|| mail == null || mail.isEmpty()) {
				out.println("all the details needed to provide this service");
				out.println(numberOfItems+" "+d_add+" "+contact+" "+pincode+" "+mail);
			} else {
				out.println("entered into exported page");
				out.println(numberOfItems+" "+d_add+" "+contact+" "+pincode+" "+mail);
				Usernamecheck.insertexport(numberItems,d_add,pincode,contact,mail,pay,username,id);
				out.println("\nYour products will be exported soon");				
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		/*try (PrintWriter out = response.getWriter()) {
			String numberOfItems = request.getParameter("no_of_items");
			String mail = request.getParameter("mail");
			String contact = request.getParameter("contact");
			String d_add = request.getParameter("deliveryat");
			String pincode = request.getParameter("pincode");
			String pay = request.getParameter("optradio");
			PaymentType pt=PaymentType.valueOf(pay);
			int numberItems=Integer.parseInt(numberOfItems);
			String username = Utility.getCookieValue(request, "auth_user");
			String id = request.getParameter("id");
			System.out.println("now the id is"+id);
			//Session session = HButil.get().openSession();
			//String hql = "select * from user_credential where auth_key!=''";
			//Query query = session.createQuery(hql);
			//List<String> userName = query.getResultList();
			//String uname="";
			//for(String var:userNamse){
				//uname=uname+var;
			//}
			if (numberItems == 0 ||d_add == null || d_add.isEmpty() || contact == null || contact.isEmpty()|| pincode == null || pincode.isEmpty()|| mail == null || mail.isEmpty()) {
				out.println("all the details needed to provide this service");
				out.println(numberOfItems+" "+d_add+" "+contact+" "+pincode+" "+mail);
			} else {
				out.println("entered into exported page");
				out.println(numberOfItems+" "+d_add+" "+contact+" "+pincode+" "+mail);
				Usernamecheck.insertexport(numberItems,d_add,pincode,contact,mail,pay,username,id);
				out.println("\nYour products will be exported soon");				
			}
		}*/
	}
	}


