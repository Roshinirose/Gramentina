package checkmethods;

import org.hibernate.Session;

import garmentina.HButil;
import tables.ExportCart;
import tables.HireCart;
import tables.UserCredential;
import tables.UserProfile;



public class Usernamecheck {
	public static UserCredential get(String username) {
		Session session = HButil.get().openSession();
		UserCredential users = session.get(UserCredential.class, username);
		session.close();
		return users;
	}
	
	public static void insert(String username, String password,String contact,String alternate,String mail) {
		Session session = HButil.get().openSession();
		session.beginTransaction();
		UserProfile userpro = new UserProfile();
		UserCredential usercred = new UserCredential();
		usercred.setUserName(username);
		usercred.setPassword(password);
		usercred.setAuthKey("");
		usercred.setActivated(false);
		userpro.setContactNumber(contact);
		userpro.setAcontactNumber(alternate);
		userpro.setEmailAddress(mail);
		userpro.setCredential(usercred);
		session.save(userpro);
		session.save(usercred);
		session.getTransaction().commit();
		session.close();
	}
	/*public static void checkinsert(String username,String password){
		Session session = HButil.get().openSession();
		session.beginTransaction();
		LoginDetails users = new LoginDetails();
		users.setUser_name(username);
		users.setPassword(password);
		session.save(users);
		session.getTransaction().commit();
		session.close();
	}*/
	public static void insertexport(int noOfItems,String deliveryAt,String pincode,String contact,String mail,String pay,String username,String stockid){
		Session session = HButil.get().openSession();
		session.beginTransaction();
		ExportCart export = new ExportCart();
		export.setNumberOfPiecesNeeded(noOfItems);
		export.setDeliveryAt(deliveryAt);
		export.setPincode(pincode);
		export.setContactNumber(contact);
		export.setMail(mail);
		export.setTypeOfPay(pay);
		export.setUserName(username);
		export.setStockId(stockid);
		//String userName = 
		session.save(export);
		session.getTransaction().commit();
		session.close();
	}
	public static void insertHire(int noOfItems,String deliveryAt,String pincode,String contact,String mail,String pay,String username,String stockid,String pickupAt,String pickUpPincode,String hireDays){
		Session session = HButil.get().openSession();
		session.beginTransaction();
		HireCart hire = new HireCart();
		hire.setNumberOfPiecesNeeded(noOfItems);
		hire.setDeliveryAt(deliveryAt);
		hire.setPincode(pincode);
		hire.setContactNumber(contact);
		hire.setMail(mail);
		hire.setTypeOfPay(pay);
		hire.setUserName(username);
		hire.setStockId(stockid);
		hire.setNumberOfHireDays(hireDays);
		hire.setPickupAt(pickupAt);
		hire.setPickUpPincode(pickUpPincode);
		//String userName = 
		session.save(hire);
		session.getTransaction().commit();
		session.close();
	}

}





