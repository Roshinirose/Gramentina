package checkmethods;

import org.hibernate.Session;
import tables.Stock;
import garmentina.HButil;
import tables.AdminTable;
import tables.Category;


public class Admin {

	public static void  insertstock(Category category,String s_id,String colour,String material,String catchycode,String price,String item_nos){
		Session session = HButil.get().openSession();
		session.beginTransaction();
		Stock stock = new Stock();
		if(category.compareTo(Category.MEN)==0){
			stock.setCategory(category.MEN);
		}
		else if(category.compareTo(Category.WOMEN)==0)
			stock.setCategory(category.WOMEN);
		else if(category.compareTo(Category.KIDS)==0)
			stock.setCategory(category.KIDS);
		else if(category.compareTo(Category.COMBO)==0)
			stock.setCategory(category.COMBO);
		stock.setCategory(category);
		stock.setStockId(s_id);
		stock.setColour(colour);
		stock.setMaterial(material);
		stock.setCatchyCode(catchycode);
		stock.setPrice(price);
		stock.setNumberOfItems(item_nos);
		session.save(stock);
		session.getTransaction().commit();
		session.close();
	}
	public static AdminTable get(String username) {
		Session session = HButil.get().openSession();
		AdminTable users = session.get(AdminTable.class, username);
		session.close();
		return users;
	}
}
