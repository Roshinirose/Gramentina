package checkmethods;

import org.hibernate.Session;


import garmentina.HButil;
import tables.ExportCart;

public class Lastclassmethods {
	public static void  insertcart(int no_of_piece,String deliveryat,String pincode,String contact,String mail,String type_of_pay,String username){
		Session session = HButil.get().openSession();
		session.beginTransaction();
		ExportCart stock = new ExportCart();
		//stock.setNo_of_pieces_needed(no_of_piece);
		//stock.setDeliveryat(deliveryat);
		stock.setPincode(pincode);
		//stock.setContact_no(contact);
		stock.setMail(mail);
		//stock.setType_of_pay(type_of_pay);
		//stock.setUsername(username);
		session.save(stock);
		session.getTransaction().commit();
		session.close();
	}
}
