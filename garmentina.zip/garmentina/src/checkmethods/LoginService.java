package checkmethods;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import garmentina.HButil;
import garmentina.Utility;
import tables.UserCredential;


public class LoginService {
	public static String validate(String username, String password) {
		System.out.println("username="+username);
		System.out.println("password="+password);
		String code = "";
		Session session = HButil.get().openSession();
		session.beginTransaction();
		UserCredential user = session.get(UserCredential.class, username);
		if (user != null && user.getPassword().equals(password)) {
			if (user.getAuthKey().isEmpty()) {
				System.out.println("the code is generated"+code);
				code = Utility.generateKey(20);
				user.setAuthKey(code);
				session.update(user);
			} else {
				System.out.println("already user name is logged in and auth key is present");
				code = "";
			}
		}
		session.getTransaction().commit();
		session.close();
		return code;
	}
	
	public static boolean logout(HttpServletResponse response, String username, String code) {
		boolean status = false;
		Session session = HButil.get().openSession();
		session.beginTransaction();
		UserCredential user = session.get(UserCredential.class, username);
		if (user != null && user.getAuthKey().equals(code)) {
			Cookie cookie = new Cookie("auth_user", "");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			cookie = new Cookie("auth_key", "");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			user.setAuthKey("");
			status = true;
			session.update(user);
		}
		session.getTransaction().commit();
		session.close();
		return status;
	}
	/*public static String store(String username){
		
	}*/

	public static boolean check(String username, String code) {
		boolean status = false;
		Session session = HButil.get().openSession();
		UserCredential user = session.get(UserCredential.class, username);
		if (user != null && user.getAuthKey().equals(code)) {
			status = true;
		}
		session.close();
		return status;
	}
}
