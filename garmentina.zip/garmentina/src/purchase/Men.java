package purchase;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import garmentina.HButil;
import tables.Category;
import tables.Stock;

/**
 * Servlet implementation class Men
 */
@WebServlet("/men")
public class Men extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Men() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try (PrintWriter out = response.getWriter()) {
			out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
			Session session = HButil.get().openSession();
			session.beginTransaction();
			String sel = "from Stock";
			Query query = session.createQuery(sel);
			List<Stock> stocks = query.getResultList();
			out.println("<table border=1>");
			out.println("<tr>");
			out.println("<th>");
			out.println("MATERIAL");
			out.println("</th>");
			out.println("<th>");
			out.println("PRICE");
			out.println("</th>");
			out.println("<th>");
			out.println("COLOUR");
			out.println("</th>");
			out.println("<th>");
			out.println("NUMBER OF ITEMS AVILABLE");
			out.println("</th>");
			out.println("<th>");
			out.println("CATCHY CODE");
			out.println("</th>");
			out.println("</tr>");
			out.println("entered into men page");
			Category cat = Category.valueOf("MEN");
			out.println(cat+"is the category");
			//System.out.println(cat.compareTo(Category.WOMEN));
			for(Stock s:stocks){
				if(s.getCategory().compareTo(cat)==0){
				out.println("<tr>"+"<td>" +s.getMaterial()+"</td>"+"<td>"+s.getPrice()+"</td>"+"<td>"+s.getColour()+"</td>"+"<td>"+s.getNumberOfItems()+"</td>"+"<td>"+s.getCatchyCode()+"</td>"+"</td>"+"<td>"+"<a href='export?id=" + s.getStockId() + "'>Export</a>"+"</td>"+"<td>"+"<a href='hire?id=" + s.getStockId() + "'>Hire</a>"+"</td>"+"</tr>");
				}
			}
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
			
			request.getRequestDispatcher("beforeneeded.html").include(request, response);
			//session.close();
			
			
			
	}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
