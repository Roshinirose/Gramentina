package checkuser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import checkmethods.Usernamecheck;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/newuser")
public class Newuser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Newuser() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String contact = request.getParameter("contact");
			String alternate = request.getParameter("alternate");
			String mail = request.getParameter("mail");
			if (username == null || username.isEmpty() || password == null || password.isEmpty() || contact == null || contact.isEmpty()|| alternate == null || alternate.isEmpty()|| mail == null || mail.isEmpty()) {
				out.println("all the details needed to provide this service");
			} else {
				Usernamecheck.insert(username, password, contact,alternate,mail);
				out.println("User Registered. <a href='login.html'>Login</a> with new user here");
				
			}
		}
	}

}



