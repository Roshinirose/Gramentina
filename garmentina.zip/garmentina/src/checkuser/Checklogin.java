package checkuser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import checkmethods.LoginService;



/**
 * Servlet implementation class CheckUsernameServlet
 */
@WebServlet("/checklogin")
public class Checklogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Checklogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("u_name");
		String password = request.getParameter("pass");
		try (PrintWriter out = response.getWriter()) {
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<h1>entered this page</h1>");
			out.println("</head>");
			out.println("<body>");
			String code = LoginService.validate(username, password);
			out.println(code);
			if (code != null) {
				out.println("entered the if condition");
				if(code.isEmpty()) {
					out.println("Already Logged in another device");
				} else {
					out.println("Logged with Access Key : " + code);
					out.println("Success : ");
					Cookie cookie = new Cookie("auth_user", username);
					cookie.setMaxAge(24 * 60 * 60);
					response.addCookie(cookie);
					cookie = new Cookie("auth_key", code);
					cookie.setMaxAge(24 * 60 * 60);
					response.addCookie(cookie);
					response.sendRedirect("purchase.html");
				}
			} else {
				request.getRequestDispatcher("login.html").include(request, response);
			}
			out.println("</body>");
			out.println("</html>");
		}
	}

	}
