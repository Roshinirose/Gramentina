package checkuser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import checkmethods.Admin;
import tables.Category;

/**
 * Servlet implementation class Productinsert
 */
@WebServlet("/productinsert")
public class Productinsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Productinsert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try (PrintWriter out = response.getWriter()) {
			String s_id = request.getParameter("s_id");
			String material = request.getParameter("material");
			String catInsert=null;
			String category=(String)request.getParameter("dropdown");
			//String category = request.getParameter("category");
			Category cat = Category.valueOf(category);
			out.println(cat+"is being selected");
			/*//
			
			if(cat.compareTo(Category.MEN)==0){
				out.println("men entered");
				//catInsert="men";
				Category.COMBO;
				//Category cat1 = Category.valueOf("MEN");
			}
			else if(cat.compareTo(Category.WOMEN)==0)
				catInsert="women";
			else if(cat.compareTo(Category.KIDS)==0)
				catInsert="kids";
			else if(cat.compareTo(Category.COMBO)==0)
				catInsert="combo";*/
			String catchycode = request.getParameter("cathcycode");
			String price = request.getParameter("price");
			String colour = request.getParameter("colour");
			String items = request.getParameter("items");
			if (s_id == null || s_id.isEmpty() || material == null || material.isEmpty() || category == null || category.isEmpty()|| catchycode == null || catchycode.isEmpty()||price == null ||price.isEmpty()||colour == null ||colour.isEmpty()|| items == null ||  items.isEmpty()) {
				out.println("enter all the details");
			} else {
				Admin.insertstock(cat, s_id, colour, material, catchycode, price,items);
				out.println("stocks are added ");
			}
		}
	}
	}


