package tables;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_profile",catalog="garmentinadb")
public class UserProfile {

	@Column(name = "contact_no", nullable = false)
	private String contactNumber;
	@Column(name = "alternate_no", nullable = false)
	private String acontactNumber;
	@Column(name = "email_id", nullable = false)
	private String emailAddress;
	@Column(name = "membership_id", nullable = false)
	@Id
	@GeneratedValue
	private Integer membershipId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "username")
	private UserCredential credential;

	

	public UserCredential getCredential() {
		return credential;
	}

	public void setCredential(UserCredential credential) {
		this.credential = credential;
	}



	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAcontactNumber() {
		return acontactNumber;
	}
	public void setAcontactNumber(String acontactNumber) {
		this.acontactNumber = acontactNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Integer getMembershipId() {
		return membershipId;
	}

	public void setMembershipId(Integer membershipId) {
		this.membershipId = membershipId;
	}

}
