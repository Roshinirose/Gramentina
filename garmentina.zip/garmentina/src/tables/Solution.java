package tables;

import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Solution {
	public static void main(String args[]) {
		/*ExportCart export = new ExportCart();
		export.setUserName("r859e1loeo");
		// export.setD_date(2001-12-05);
		export.setDeliveryAt("krishna nagar");
		HireCart hire = new HireCart();
		hire.setUserName("d48eeyhte62");
		hire.setDeliveryAt("juhyijjff");
		UserProfile userpro = new UserProfile();
		UserCredential usercred = new UserCredential();
		usercred.setUserName("roshini");
		usercred.setPassword("abcf");
		usercred.setAuthKey("wfwg");
		usercred.setActivated(true);
		userpro.setCredential(usercred);
		userpro.setContactNumber("08098");
		userpro.setAcontactNumber("879869");
		userpro.setEmailAddress("tjyguyku"); 
		
		SessionFactory s = new Configuration().configure().buildSessionFactory();
		Session session = s.openSession();
		session.beginTransaction();
		//session.save(export);
		//session.save(hire);
		session.save(usercred);
		session.save(userpro);
		session.getTransaction().commit();
		session.close();*/
		Category cat = Category.valueOf("MEN");
		System.out.println(cat.compareTo(Category.MEN));
		Category cats[] = Category.values();
		System.out.println(Arrays.asList(cat));
	}
}
