package tables;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "exportcart", catalog = "garmentinadb")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class ExportCart {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Sno")
	int sno;
	@Column(name = "username")
	private String userName;
	@Column(name = "number_of_pieces_needed")
	private int numberOfPiecesNeeded;
	@Column(name = "delivery_address")
	private String deliveryAt;
	@Column(name = "pincode")
	private String pincode;
	@Column(name = "contact_number")
	private String contactNumber;
	@Column(name = "mail_address")
	private String mail;
	@Column(name = "pay_type")
	private String typeOfPay;
	@Column(name = "stock_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String stockId;
	//@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="credential")
	//private ExportCart exportcart;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getNumberOfPiecesNeeded() {
		return numberOfPiecesNeeded;
	}

	public void setNumberOfPiecesNeeded(int numberOfPiecesNeeded) {
		this.numberOfPiecesNeeded = numberOfPiecesNeeded;
	}

	public String getDeliveryAt() {
		return deliveryAt;
	}

	public void setDeliveryAt(String deliveryAt) {
		this.deliveryAt = deliveryAt;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getStockId() {
		return stockId;
	}

	public void setStockId(String stockId) {
		this.stockId = stockId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTypeOfPay() {
		return typeOfPay;
	}

	public void setTypeOfPay(String typeOfPay) {
		this.typeOfPay = typeOfPay;
	}

	/*public ExportCart getExportcart() {
		return exportcart;
	}

	public void setExportcart(ExportCart exportcart) {
		this.exportcart = exportcart;
	}*/
	

}
