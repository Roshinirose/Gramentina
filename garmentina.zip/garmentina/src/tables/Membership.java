package tables;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "membership", catalog = "garmentinadb")
public class Membership {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "membership_id")
	private String membershipId;
	@Column(name = "no_of_items_purchased")
	private int itemsPurchased;
	@Column(name = "active_hours")
	private int activeHours;

	public String getMembershipId() {
		return membershipId;
	}

	public void setMembershipId(String membershipId) {
		this.membershipId = membershipId;
	}

	public int getItemsPurchased() {
		return itemsPurchased;
	}

	public void setItemsPurchased(int itemsPurchased) {
		this.itemsPurchased = itemsPurchased;
	}

	public int getActiveHours() {
		return activeHours;
	}

	public void setActiveHours(int activeHours) {
		this.activeHours = activeHours;
	}

}
