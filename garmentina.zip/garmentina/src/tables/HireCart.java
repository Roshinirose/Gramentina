package tables;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hirecart", catalog = "garmentinadb")
public class HireCart extends ExportCart {

	@Column(name = "number_of_hire_days")
	private String numberOfHireDays;
	@Column(name = "pickup_address")
	private String pickupAt;
	@Column(name = "pickup_pincode")
	private String pickUpPincode;
	@Column(name = "fine")
	private String fine;

	public String getNumberOfHireDays() {
		return numberOfHireDays;
	}

	public void setNumberOfHireDays(String numberOfHireDays) {
		this.numberOfHireDays = numberOfHireDays;
	}

	public String getPickupAt() {
		return pickupAt;
	}

	public void setPickupAt(String pickupAt) {
		this.pickupAt = pickupAt;
	}

	public String getPickUpPincode() {
		return pickUpPincode;
	}

	public void setPickUpPincode(String pickUpPincode) {
		this.pickUpPincode = pickUpPincode;
	}

	public String getFine() {
		return fine;
	}

	public void setFine(String fine) {
		this.fine = fine;
	}
}
