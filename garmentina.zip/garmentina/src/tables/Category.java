package tables;

public enum Category {
	WOMEN, MEN, KIDS, COMBO
}
