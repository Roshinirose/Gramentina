package tables;

public enum PaymentType {
	CASH_ON_DELIVERY,NET_BANKING;
}
