package tables;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Entity
@Table(name = "stock", catalog = "garmentinadb")
public class Stock {
	@Id
	@Column(name = "stock_id")
	private String stockId;
	@Column(name = "no_of_items")
	private String NumberOfItems;
	@Column(name = "material")
	private String material;
	@Column(name = "price")
	private String price;
	@Column(name = "colour")
	private String colour;
	@Column(name = "catchy_code")
	private String catchyCode;
	@Column(name = "category")
	@Enumerated(EnumType.STRING)// @Enumerated(EnumType.STRING)
	private Category category; // Create Enum - Women, Kids, Combo, Men

	
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getStockId() {
		return stockId;
	}

	public void setStockId(String stockId) {
		this.stockId = stockId;
	}

	public String getNumberOfItems() {
		return NumberOfItems;
	}

	public void setNumberOfItems(String numberOfItems) {
		NumberOfItems = numberOfItems;
	}

	public String getCatchyCode() {
		return catchyCode;
	}

	public void setCatchyCode(String catchyCode) {
		this.catchyCode = catchyCode;
	}

}
